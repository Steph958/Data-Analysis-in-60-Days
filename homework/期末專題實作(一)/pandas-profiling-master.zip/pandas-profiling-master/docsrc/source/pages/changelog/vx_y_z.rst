Changelog vx.y.z
----------------

🎉 Features
^^^^^^^^^^^
-

🐛 Bug fixes
^^^^^^^^^^^^
-

👷‍♂️ Internal Improvements
^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-

📖 Documentation
^^^^^^^^^^^^^^^^
-

⚠️  Deprecated
^^^^^^^^^^^^^^^^^
-

🚨 Breaking changes
^^^^^^^^^^^^^^^^^^^
-

⬆️ Dependencies
^^^^^^^^^^^^^^^^^^
-