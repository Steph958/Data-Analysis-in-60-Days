=============
Visualisation
=============

Plot
----

.. currentmodule:: pandas_profiling.visualisation
.. toctree::

.. autosummary::
   :toctree: _autosummary

   plot

Missing
-------

.. currentmodule:: pandas_profiling.visualisation
.. toctree::

.. autosummary::
   :toctree: _autosummary

   missing


Utils
-----

.. currentmodule:: pandas_profiling.visualisation
.. toctree::

.. autosummary::
   :toctree: _autosummary

   utils
