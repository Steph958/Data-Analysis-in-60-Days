=====
Utils
=====

.. currentmodule:: pandas_profiling.utils
.. toctree::

.. autosummary::
   :toctree: _autosummary

   cache
   common
   dataframe
   notebook
   paths
