"""Data structure for the report"""
